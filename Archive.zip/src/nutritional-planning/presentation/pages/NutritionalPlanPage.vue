<script setup>
import { computed, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useToast } from 'primevue/usetoast'
import Button from 'primevue/button'
import Message from 'primevue/message'
import Tag from 'primevue/tag'
import { useIdentityAccessStore } from '../../../identity-access/application/identity-access.store'
import { usePatientPlanStore } from '../../application/patient-plan.store'
import { usePatientProgressStore } from '../../../progress-tracking/application/patient-progress.store'

const router = useRouter()
const toast = useToast()
const identityAccessStore = useIdentityAccessStore()
const patientPlanStore = usePatientPlanStore()
const patientProgressStore = usePatientProgressStore()

onMounted(async () => {
  await identityAccessStore.refreshCurrentUser()
  const plan = await patientPlanStore.fetchPatientPlan()
  patientProgressStore.setDailyTargetCalories(plan?.targetCalories ?? 1850)
})

const plan = computed(() => patientPlanStore.currentPlan)
const requiresEmailVerification = computed(() => !identityAccessStore.hasVerifiedAccount)

async function acceptPlan() {
  await patientPlanStore.acceptPlan()
}

async function verifyEmail() {
  await identityAccessStore.verifyEmail()
  toast.add({
    severity: 'success',
    summary: 'Correo verificado',
    detail: 'Correo verificado correctamente',
    life: 3000,
  })
  const plan = await patientPlanStore.fetchPatientPlan()
  patientProgressStore.setDailyTargetCalories(plan?.targetCalories ?? 1850)
}
</script>

<template>
  <section class="bt-plan-page">
    <header class="bt-patient-heading">
      <div>
        <p class="microcopy">Plan nutricional</p>
        <h1>
          {{
            patientPlanStore.hasProposedPlan
              ? 'Revisar plan propuesto'
              : patientPlanStore.hasActivePlan
                ? 'Plan nutricional activo'
                : 'Plan nutricional'
          }}
        </h1>
        <p class="text-muted">
          {{
            patientPlanStore.hasProposedPlan
              ? 'Tu nutricionista ha preparado un plan personalizado para ti.'
              : patientPlanStore.hasActivePlan
                ? 'Tu plan ya esta disponible y listo para seguir.'
                : 'Aún no tienes un plan nutricional activo.'
          }}
        </p>
      </div>
      <Tag
        v-if="patientPlanStore.hasProposedPlan || patientPlanStore.hasActivePlan"
        :value="patientPlanStore.hasActivePlan ? 'Plan activo' : 'Estado: Propuesto'"
        :severity="patientPlanStore.hasActivePlan ? 'success' : 'warn'"
      />
    </header>

    <Message v-if="requiresEmailVerification" severity="warn" class="bt-verification-message">
      <div class="bt-verification-content">
        <span>Tu correo aún no ha sido verificado. Verifica tu cuenta para acceder a todas las funcionalidades.</span>
        <Button
          label="Verificar correo"
          size="small"
          :loading="identityAccessStore.loading"
          @click="verifyEmail"
        />
      </div>
    </Message>

    <section v-if="requiresEmailVerification" class="bt-empty-plan-layout">
      <article class="bt-empty-plan-card">
        <div class="bt-empty-icon">!</div>
        <h2>Verifica tu correo</h2>
        <p>Necesitas verificar tu cuenta para acceder al flujo del Plan Nutricional.</p>
        <Button
          label="Verificar correo"
          :loading="identityAccessStore.loading"
          @click="verifyEmail"
        />
      </article>
    </section>

    <section v-else-if="patientPlanStore.hasProposedPlan || patientPlanStore.hasActivePlan" class="bt-plan-grid">
      <article class="bt-dashboard-panel bt-plan-main-card">
        <div class="bt-panel-header">
          <div>
            <h3>{{ plan?.title }}</h3>
            <p class="text-muted">Elaborado por {{ plan?.nutritionist }} - {{ plan?.date }}</p>
          </div>
        </div>

        <div class="bt-plan-preview">
          <span>☀️ Avena + fruta</span>
          <span>🍽️ Pollo + arroz</span>
          <span>🌙 Ensalada</span>
        </div>

        <Message v-if="patientPlanStore.acceptedRecently" severity="success" class="bt-plan-message">
          <strong>Plan aceptado exitosamente</strong>
          <span>El plan quedo activado y ya esta disponible en tu Vista de Dieta Semanal.</span>
        </Message>

        <div v-if="patientPlanStore.hasProposedPlan" class="bt-plan-actions">
          <Button label="Aceptar plan" :loading="patientPlanStore.loading" @click="acceptPlan" />
          <Button label="Rechazar plan" outlined @click="patientPlanStore.rejectPlan()" />
        </div>
      </article>

      <aside class="bt-plan-side">
        <article class="bt-plan-highlight">
          <span>Calorias diarias</span>
          <strong>{{ plan?.targetCalories }} kcal</strong>
          <small>Objetivo: {{ plan?.goal }}</small>
        </article>

        <article class="bt-dashboard-panel">
          <h3>Macronutrientes</h3>
          <div class="bt-macro-row"><span>Proteinas</span><strong>{{ plan?.macros.proteins }}%</strong></div>
          <div class="bt-goal-track bt-goal-track--blue"><span /></div>
          <div class="bt-macro-row"><span>Carbohidratos</span><strong>{{ plan?.macros.carbohydrates }}%</strong></div>
          <div class="bt-goal-track bt-goal-track--green"><span /></div>
          <div class="bt-macro-row"><span>Grasas</span><strong>{{ plan?.macros.fats }}%</strong></div>
          <div class="bt-goal-track bt-goal-track--warning"><span /></div>
        </article>

        <Button
          v-if="patientPlanStore.hasActivePlan"
          label="Ver mi dieta semanal"
          @click="router.push('/weekly-diet')"
        />
      </aside>
    </section>

    <section v-else class="bt-empty-plan-layout">
      <article class="bt-empty-plan-card">
        <div class="bt-empty-icon">✓</div>
        <h2>Sin plan nutricional</h2>
        <p>Aún no tienes un plan nutricional activo.</p>
        <Button label="Completar mi perfil de salud" @click="router.push('/patient-profile')" />
      </article>
    </section>
  </section>
</template>
